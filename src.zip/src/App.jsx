
import './App.css'

import Landing from './components/Home/Landing'

function App() {

  return (
    <>
    <Landing/>
    
    </>
  )
}

export default App
