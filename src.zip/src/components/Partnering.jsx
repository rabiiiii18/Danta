import React from "react";
import { motion } from "framer-motion";
import Doctors from "./Doctors";

const Partnering = () => {
  return (
    <div className="relative">
      <div className="flex justify-between ">
        <div className="pt-30 px-8 h-[130vh] w-[50%] border-e border-e-gray-300 bg-[#f7f7f7] ">
          <span className="text-[20px] leading-[28px] font-normal">
            / Partnering in health
          </span>
          <h1 className="text-[72px] leading-[85px] mt-5 relative  w-[112%] overflow-hidden  ">
            Intellec presentation
          </h1>
          <span className="text-[24px] leading-[34px] font-normal mt-16 ">
            Preventative & restorative dental treatments
          </span>
        </div>
        <div className="w-[50%] pt-25">
          <motion.h1
            className="text-[330px] leading-[260px] text-[#EEE2D9] text-center "
            animate={{
              x: [0, -5, 2, -1, 1, 0],
            }}
            transition={{
              duration: 5,
              delay: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            1997
          </motion.h1>
        </div>
      </div>
      <div className="absolute top-[40%]">
        <Doctors />
      </div>

      
    </div>

  );
};

export default Partnering;
